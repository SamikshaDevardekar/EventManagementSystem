package com.example.eventmanagementsystemproject.service;

import com.example.eventmanagementsystemproject.model.Attendee;
import com.example.eventmanagementsystemproject.repository.AttendeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AttendeeService {

    @Autowired
    private AttendeeRepository attendeeRepository;

    // Save attendee (on registration)
    public void saveAttendee(Attendee attendee) {
        attendee.setCheckInTime(LocalDateTime.now());
        attendee.setCheckedIn(true);
        attendeeRepository.save(attendee);
    }

    // Retrieve all attendees
    public List<Attendee> getAllAttendees() {
        return attendeeRepository.findAll();
    }

    // Get attendee by ID
    public Attendee getAttendeeById(Long id) {
        return attendeeRepository.findById(id).orElse(null);
    }

    // Delete attendee by ID
    public void deleteAttendeeById(Long id) {
        attendeeRepository.deleteById(id);
    }

    // Get attendees by eventId
    public List<Attendee> getAttendeesByEvent(Long eventId) {
        return attendeeRepository.findByEventId(eventId); // This depends on the repository implementation
    }

    // Check-in attendee
    public void checkInAttendee(Long attendeeId) {
        Attendee attendee = attendeeRepository.findById(attendeeId).orElse(null);
        if (attendee != null) {
            attendee.setCheckInTime(LocalDateTime.now());
            attendee.setCheckedIn(true);
            attendeeRepository.save(attendee);
        }
    }

    // Check-out attendee
    public void checkOutAttendee(Long attendeeId) {
        Attendee attendee = attendeeRepository.findById(attendeeId).orElse(null);
        if (attendee != null) {
            attendee.setCheckOutTime(LocalDateTime.now());
            attendee.setCheckedIn(false);
            attendeeRepository.save(attendee);
        }
    }
}
