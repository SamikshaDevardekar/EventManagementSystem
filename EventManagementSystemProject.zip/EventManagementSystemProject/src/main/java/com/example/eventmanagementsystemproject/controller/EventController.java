package com.example.eventmanagementsystemproject.controller;

import com.example.eventmanagementsystemproject.service.AttendeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/event")
public class EventController {

    @Autowired
    private AttendeeService attendeeService;

    // View attendees for a particular event
    @GetMapping("/attendees/{eventId}")
    public String viewEventAttendees(@PathVariable("eventId") Long eventId, Model model) {
        model.addAttribute("attendees", attendeeService.getAttendeesByEvent(eventId));
        return "event_attendees"; // Return the appropriate Thymeleaf template
    }
}
