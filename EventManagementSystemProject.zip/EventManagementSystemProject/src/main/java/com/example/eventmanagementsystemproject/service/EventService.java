package com.example.eventmanagementsystemproject.service;

import com.example.eventmanagementsystemproject.model.Event;
import com.example.eventmanagementsystemproject.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service // Marks this class as a Spring service
public class EventService {

    @Autowired
    private EventRepository eventRepository;

    // Retrieve all events
    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }

    // Get event by ID
    public Event getEventById(Long id) {
        return eventRepository.findById(id).orElse(null);
    }

    // Save or update an event
    public void saveOrUpdateEvent(Event event) {
        eventRepository.save(event);
    }

    // Delete an event by ID
    public void deleteEventById(Long id) {
        eventRepository.deleteById(id);
    }
}
