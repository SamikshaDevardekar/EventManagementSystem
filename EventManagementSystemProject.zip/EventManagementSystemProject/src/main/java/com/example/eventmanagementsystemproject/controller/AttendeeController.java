package com.example.eventmanagementsystemproject.controller;

import com.example.eventmanagementsystemproject.model.Attendee;
import com.example.eventmanagementsystemproject.service.AttendeeService;
import com.example.eventmanagementsystemproject.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/attendee")
public class AttendeeController {

    @Autowired
    private AttendeeService attendeeService;

    @Autowired
    private EventService eventService; // Add this line to inject the EventService

    // Show form to register an attendee
    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("attendee", new Attendee());
        model.addAttribute("events", eventService.getAllEvents()); // Fetch list of events
        return "attendee_register"; // Return the registration form template
    }

    // Handle attendee registration
    @PostMapping("/register")
    public String registerAttendee(@ModelAttribute Attendee attendee) {
        attendeeService.saveAttendee(attendee); // Save the attendee
        return "redirect:/attendee/registration-success"; // Redirect to the success page after registration
    }

    // Show all attendees
    @GetMapping("/list")
    public String listAttendees(Model model) {
        model.addAttribute("attendees", attendeeService.getAllAttendees());
        return "attendee_list"; // The name of your Thymeleaf template for displaying attendees
    }

    // Edit attendee (GET request to show the form)
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        Attendee attendee = attendeeService.getAttendeeById(id);
        if (attendee != null) {
            model.addAttribute("attendee", attendee);
            model.addAttribute("events", eventService.getAllEvents()); // Add list of events for selection
            return "edit_attendee"; // Name of the edit form template
        } else {
            return "redirect:/attendee/list"; // Redirect to the attendee list if not found
        }
    }

    // Edit attendee (POST request to update)
    @PostMapping("/edit/{id}")
    public String updateAttendee(@PathVariable("id") Long id, @ModelAttribute("attendee") Attendee attendee) {
        attendeeService.saveAttendee(attendee); // Save updated attendee
        return "redirect:/attendee/list"; // Redirect to the list page after saving
    }

    // Check-in attendee
    @GetMapping("/checkin/{id}")
    public String checkInAttendee(@PathVariable("id") Long id) {
        attendeeService.checkInAttendee(id); // Call service method for check-in
        return "redirect:/attendee/list"; // Redirect to list after check-in
    }

    // Check-out attendee
    @GetMapping("/checkout/{id}")
    public String checkOutAttendee(@PathVariable("id") Long id) {
        attendeeService.checkOutAttendee(id); // Call service method for check-out
        return "redirect:/attendee/list"; // Redirect to list after check-out
    }

    // Delete attendee (optional)
    @GetMapping("/delete/{id}")
    public String deleteAttendee(@PathVariable("id") Long id) {
        attendeeService.deleteAttendeeById(id); // Call service method for delete
        return "redirect:/attendee/list"; // Redirect to list after deletion
    }

    // Show registration success page
    @GetMapping("/registration-success")
    public String showRegistrationSuccess() {
        return "registration_success"; // Return the success page template
    }
}
