package com.example.eventmanagementsystemproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventManagementSystemProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(EventManagementSystemProjectApplication.class, args);
    }

}
