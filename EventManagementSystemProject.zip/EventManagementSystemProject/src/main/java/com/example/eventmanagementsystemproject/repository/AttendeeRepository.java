package com.example.eventmanagementsystemproject.repository;

import com.example.eventmanagementsystemproject.model.Attendee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AttendeeRepository extends JpaRepository<Attendee, Long> {
    List<Attendee> findByEventId(Long eventId); // Custom query to find visitors by event ID
}
