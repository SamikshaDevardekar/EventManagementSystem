package com.example.eventmanagementsystemproject.controller;

import com.example.eventmanagementsystemproject.service.AttendeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AttendeeService attendeeService;

    // View all attendees
    @GetMapping("/all-attendees")
    public String viewAllAttendees(Model model) {
        model.addAttribute("attendees", attendeeService.getAllAttendees());
        return "admin_attendee_list"; // Return the appropriate Thymeleaf template
    }
}
